import streamlit as st
import requests

# Define the backend API URL
API_URL = "http://127.0.0.1:8888/predict/"  # Update with your deployed FastAPI URL if hosted

# Streamlit App Title
st.title("Insurance Prediction")

# Input Features
st.header("Enter Insurance Details:")
age = st.number_input("Age:", value=30.0)
bmi = st.number_input("BMI:", value=25.0)
charges = st.number_input("Charges:", value=15000.0)
children = st.number_input("Number of Children:", value=0, step=1)
age_bmi_interaction = st.number_input("Age-BMI Interaction:", value=750.0)
children_charges_ratio = st.number_input("Children-Charges Ratio:", value=0.0)
log_charges = st.number_input("Log Charges:", value=9.61)
sex = st.selectbox("Sex:", ["male", "female"])
region = st.selectbox("Region:", ["northeast", "northwest", "southeast", "southwest"])

# Preprocess categorical features
sex_encoded = 1 if sex == "male" else 0
region_encoded = {"northeast": 0, "northwest": 1, "southeast": 2, "southwest": 3}.get(region, 0)

# Create feature array
features = [
    age, bmi, charges, children,
    age_bmi_interaction, children_charges_ratio,
    log_charges, sex_encoded, region_encoded
]

# Predict Button
if st.button("Predict Insurance Outcome"):
    try:
        # Make POST request to FastAPI
        response = requests.post(API_URL, json={"features": features})
        
        # Check if the API call is successful
        if response.status_code == 200:
            response_data = response.json()
            prediction = response_data.get("prediction", None)

            if prediction is not None:
                if prediction == 1:
                    st.success("Positive Insurance Outcome")
                else:
                    st.error("Negative Insurance Outcome")
            else:
                st.error("Unexpected response format from API. Check the API.")
        else:
            st.error(f"API call failed with status code {response.status_code}")

    except Exception as e:
        st.error(f"Error: {e}")
