from fastapi import FastAPI
import joblib
import numpy as np

# Initialize the FastAPI app
app = FastAPI()

# Load the trained model
model = joblib.load("final_model.joblib")

@app.get("/")
def read_root():
    return {"message": "Welcome to the Insurance Prediction API"}

@app.post("/predict/")
def predict(features: list[float]):
    """
    Predict insurance outcomes.
    Pass a JSON array of feature values for prediction.
    """
    # Ensure input is in the correct shape for the model
    features_array = np.array(features).reshape(1, -1)
    prediction = model.predict(features_array)
    probability = model.predict_proba(features_array).tolist()
    return {
        "prediction": int(prediction[0]),
        "probability": probability
    }
